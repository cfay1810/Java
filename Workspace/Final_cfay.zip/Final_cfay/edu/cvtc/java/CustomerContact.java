/**

 * 
 */
package edu.cvtc.java;
import javax.swing.*;

import java.awt.event.*;
/**
 * @author Chelsey Fay

 */

	public abstract class CustomerContact extends JFrame
	{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
			private JPanel panel;
			private JLabel FNAME_LABEL;
			private JLabel LNAME_LABEL;
			private JLabel EMAIL_ADDRESS_LABEL;
			private JLabel PHONENUMBER_LABEL;
			private JButton customerButton;
			private JTextField Fname;
			private JTextField Lname;
			private JTextField emailAddress;
			private JTextField phoneNumber;
			private final int WINDOW_WIDTH = 420;
			private final int WINDOW_HEIGHT = 375;
			
			/**
			 * Constructor
			 */
			
			public CustomerContact(){
				
				super("Customer Contact");
				
				//Set the size of the window
				setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
				
				//Specify what happens when exit button is clicked
				setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

				//Build Panel and add it to the frame
				buildPanel();
				
				//Add Panel to the contents frame
				add(panel);
				
				//Display Panel
				setVisible(true);
				
			}
			public static void main(String[] args)
			{
				CustomerContact cc = new CustomerContact();
				}
			private void buildPanel()
			{
				//Create labels and text fields to go into panel
				FNAME_LABEL = new JLabel("First Name:");
				LNAME_LABEL = new JLabel("Last Name:");
				EMAIL_ADDRESS_LABEL = new JLabel("Email Address:");
				PHONENUMBER_LABEL = new JLabel("Phone Number:");
				customerButton = new JButton("Add Customer");
				
				//Create the panel to hold the components
				panel = new JPanel();
				
				//Add the label, text field, and button to the panel
				panel.add(FNAME_LABEL);
				panel.add(LNAME_LABEL);
				panel.add(EMAIL_ADDRESS_LABEL);
				panel.add(PHONENUMBER_LABEL);
				panel.add(customerButton);
				
				private abstract void addActionListener();{
						customerButton.addActionListener(new CustomerButton());
					}
					
					class CustomerButton implements ActionListener{
						
						@Override
						public void actionPerformed(ActionEvent arg0) {
							// TODO Auto-generated method stub
							{
								String str;
								
								str = Fname.getText();
								str = Lname.getText();
								str = emailAddress.getText();
								str = phoneNumber.getText();
								
								//Display Message
								JOptionPane.showMessageDialog(null, str);
								System.out.println("First Name: " + Fname + "Last Name: " + Lname
							+ "Email Address: " + emailAddress + "Phone Number: " + phoneNumber);
						}	
					}
				}
		}		
	}
		
}



