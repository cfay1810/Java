/**
 * 
 */
package edu.cvtc.java;

/**
 * @author Chelsey Fay
 *
 */
public class Contact extends Person {

	
	private String emailAddress;
	private String phoneNumber;
	
	public Contact(String Fname, String Lname, String emailAddress, String phoneNumber, String Person) {
		super(Fname, Lname);
		this.emailAddress = emailAddress;
		this.phoneNumber = phoneNumber;
		
	}
	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	
	public String getphoneNumber() {
		return phoneNumber;
	}

	public void setphoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	@Override
	public void CustomerContact(){
		//TODO Auto-generated method stub
	}

}
