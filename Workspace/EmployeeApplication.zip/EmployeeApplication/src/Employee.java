import java.util.Calendar;
import java.util.Date;
/**
 * 
 */

/**
 * @author Chelsey Fay
 *
 */
public class Employee {

	//Declare employee variables
	private String employeeName;
	private String employeeNumber;
	private String hireDate;
	
	//Date objects
	Calendar rightNow = Calendar.getInstance();
	Date today = new Date(rightNow.getTimeInMillis());
	private String correctFormat;
	
	//Declare variable values
	public Employee(String employeeName, String employeeNumber, String hireDate){
		this.employeeName = employeeName;
		this.employeeNumber.contains(correctFormat);
		this.hireDate = hireDate;
		this.setCorrectFormat("ZZ-1234");
		
	}

	//Override Constructor
	@Override
	public String toString(){
		return "Employee [employee name: "  + employeeName  + " ,employee number" 
				+ employeeNumber + " ,hire date" + hireDate + "]";
	}

	public static String setemployeeName(String Ename) {
		// TODO Auto-generated method stub
		return Ename;
	}

	public static String setemployeeNumber(String eNumber) {
		// TODO Auto-generated method stub
		return eNumber;
	}

	public String getCorrectFormat() {
		return correctFormat;
	}

	public void setCorrectFormat(String correctFormat) {
		this.correctFormat = correctFormat;
	}

	public static String sethireDate(String hDate) {
		// TODO Auto-generated method stub
		return hDate;
	}
	

	
	}

