

/**
 * @author chelsey
 *
 */
public class ShiftSupervisorTestApp {

	/**
	 * 
	 */
	public ShiftSupervisorTestApp() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Give variables attributes
				String Ename = "Chelsey";
				String Enumber = "CF-7492";
				String hDate = "01-12-2015";
				String aSalary = "$35,000";
				String aBonus = "$3,200";
				
				Employee.setemployeeName(Ename);
				Employee.setemployeeNumber(Enumber);
				Employee.sethireDate(hDate);
				ShiftSupervisor.setannualSalary(aSalary);
				ShiftSupervisor.setannualBonus(aBonus);
				

				System.out.println("The employees name is: " + Ename);
				System.out.println("The employees number is: " + Enumber);
				System.out.println("The employees hire date is: " + hDate);
				System.out.println("The employees annual salary is: " + aSalary);
				System.out.println("The employees annual bonus is: " + aBonus);
				}
	}

