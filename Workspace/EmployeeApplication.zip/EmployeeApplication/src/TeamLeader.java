import java.util.Calendar;
import java.util.Date;

/**
 * 
 */

/**
 * @author Chelsey Fay
 *
 */
public class TeamLeader extends ProductionWorker
{

	/**
	 * @param args
	 */
	
	//Declare Variables
	private double monthlyBonus;
	private int requiredTrainngHours;
	private int trainingHoursAttended;

	//Date objects
	Calendar rightNow = Calendar.getInstance();
	Date today = new Date(rightNow.getTimeInMillis());
	
	//Declare Constructors
	public TeamLeader(String employeeName, String employeeNumber, String hireDate, int Shift, 
			double hourlyPay, double monthlyBonus, int requiredTrainngHours, int trainingHoursAttended){
		super(employeeName, employeeNumber, hireDate, Shift, hourlyPay);
		this.monthlyBonus = monthlyBonus;
		this.requiredTrainngHours = requiredTrainngHours;
		this.trainingHoursAttended = trainingHoursAttended;
	}
		
		@Override 
		public String toString(){
			return "TeamLeader{Employee: " + super.toString() + ", monthly bonus: " + monthlyBonus +
					" , required trainng hours: " + requiredTrainngHours + " ,training hours attended:  " + trainingHoursAttended + "}";
		}

		public static String setmonthlyBonusy(String mBonus) {
			// TODO Auto-generated method stub
			return mBonus;
		}

		public static String setrequiredTrainngHours(String rtHours) {
			// TODO Auto-generated method stub
			return rtHours;
		}

		public static String settrainingHoursAttended(String thAttended) {
			// TODO Auto-generated method stub
			return thAttended;
		}	
		
	}
