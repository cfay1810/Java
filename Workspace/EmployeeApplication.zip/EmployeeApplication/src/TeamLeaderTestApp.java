

/**
 * @author chelsey
 *
 */
public class TeamLeaderTestApp {

	/**
	 * 
	 */
	public TeamLeaderTestApp() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Give variables attributes
				String Ename = "Chelsey";
				String Enumber = "CF-7492";
				String hDate = "01-12-2015";
				String mBonus = "$250.00";
				String rtHours = "85";
				String thAttended = "14";
				
				Employee.setemployeeName(Ename);
				Employee.setemployeeNumber(Enumber);
				Employee.sethireDate(hDate);
				TeamLeader.setmonthlyBonusy(mBonus);
				TeamLeader.setrequiredTrainngHours(rtHours);
				TeamLeader.settrainingHoursAttended(thAttended);
				
				

				System.out.println("The employees name is: " + Ename);
				System.out.println("The employees number is: " + Enumber);
				System.out.println("The employees hireDate is: " + hDate);
				System.out.println(Ename + " monthly bonus is: " + mBonus+ ". ");
				System.out.println(Ename + "'s required training hours: " + rtHours);
				System.out.println(Ename + "'s required training hours: " + rtHours);
				System.out.println(Ename + " has completed " + thAttended + " training hours.");


				}
	}

