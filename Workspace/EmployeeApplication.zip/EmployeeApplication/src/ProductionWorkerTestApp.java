/**
 * 
 */

/**
 * @author Chelsey Fay
 *
 */
public class ProductionWorkerTestApp{

	/**
	 * 
	 */
	public ProductionWorkerTestApp() {
		// TODO Auto-generated constructor stub
	}
		public static void main(String[] args) {
			
			
		//Give variables attributes
		String Ename = "Chelsey";
		String Enumber = "CF-7492";
		String hDate = "01-12-2015";
		String eShift = "First Shift";
		String Hpay = "$14.35";
		
		Employee.setemployeeName(Ename);
		Employee.setemployeeNumber(Enumber);
		Employee.sethireDate(hDate);
		ProductionWorker.sethourlyPay(Hpay);
		ProductionWorker.setShift(eShift);
		
		

		System.out.println("The employees name is: " + Ename);
		System.out.println("The employees number is: " + Enumber);
		System.out.println("The employees hireDate is: " + hDate);
		System.out.println(Ename + " works " + eShift + ". ");
		System.out.println(Ename + "'s hourly pay is " + Hpay);
		}
	}
