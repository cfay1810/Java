import java.util.Calendar;
import java.util.Date;


/**
 * 
 */
/**
 * @author Chelsey Fay
 *
 */
public class ShiftSupervisor extends Employee {

	/**
	 * @param args
	 */
	private double annualSalary;
	private double annualBonus;
	
	//Date objects
	Calendar rightNow = Calendar.getInstance();
	Date today = new Date(rightNow.getTimeInMillis());
	
	public ShiftSupervisor(String employeeName, String employeeNumber, String hireDate, double annualSalary, double annualBonus){
		super(employeeName, employeeNumber, hireDate);
		this.annualSalary = annualSalary;
		this.annualBonus = annualBonus;
	}
	
	@Override
	public String toString(){
		return "ShiftSupervisor{Employee : " + super.toString() + ", annual salary: " + annualSalary + 
				", annual bonus: " + annualBonus + "}";
		}

	public static Object setannualSalary(Object aSalary) {
		// TODO Auto-generated method stub
		return aSalary;
	}

	public static Object setannualBonus(Object aBonus) {
		// TODO Auto-generated method stub
		return aBonus;
	}

}
