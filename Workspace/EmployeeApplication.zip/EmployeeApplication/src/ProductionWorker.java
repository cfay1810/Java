import java.util.Calendar;
import java.util.Date;
/**
 * 
 */

/**
 * @author Chelsey Fay
 *
 */
public class ProductionWorker extends Employee {
	
	//Declare Variables
	private int Shift;
	private double hourlyPay;

	//Date objects
	Calendar rightNow = Calendar.getInstance();
	Date today = new Date(rightNow.getTimeInMillis());

	//Create Constructors
	public ProductionWorker(String employeeName, String employeeNumber, String hireDate, int Shift, double hourlyPay){
		super(employeeName, employeeNumber, hireDate);
		this.Shift = Shift;
		this.hourlyPay = hourlyPay;
		
	}
	
	//Override Constructor
	@Override
	public String toString(){
		return "Production Worker {Employee: " + super.toString() + ", shift: " + Shift + ", hourly pay: " + hourlyPay +
				" ,shift: " + Shift + "}";
	}

	public static void sethourlyPay(String hpay) {
		// TODO Auto-generated method stub
		
	}

	public static void setShift(String eShift) {
		// TODO Auto-generated method stub
		
	}

	}
