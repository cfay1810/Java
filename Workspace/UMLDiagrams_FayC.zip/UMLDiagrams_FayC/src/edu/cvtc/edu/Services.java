/**
 * 
 */
package edu.cvtc.edu;

/**
 * @author Chelsey Fay
 *
 */
public class Services {

	public String serviceType;
	public String serviceDesc;
	
	public String getserviceType() {
		return serviceType;
	}
	
	public void setsericeType(String serviceType){
		this.serviceType = serviceType;
	}
	
	public String getserviceDesc() {
		return serviceDesc;
	}
	
	public void setserviceDesc(String serviceDesc){
		this.serviceDesc = serviceDesc;
	}
}
