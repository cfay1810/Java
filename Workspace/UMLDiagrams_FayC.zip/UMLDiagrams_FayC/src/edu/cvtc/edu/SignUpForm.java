/**
 * 
 */
package edu.cvtc.edu;

/**
 * @author Chelsey Fay
 *
 */
public class SignUpForm {

	private String customerName;
	public String serviceType;
	
	public String getcustomerName() {
		return customerName;
	}
	
	public void setcustomerName(String customerName){
		this.customerName = customerName;
	}
	
	public String getserviceType() {
		return serviceType;
	}
	
	public void setserviceType(String serviceType){
		this.serviceType = serviceType;
	}
}
