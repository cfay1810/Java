/**
 * 
 */
package edu.cvtc.edu;

/**
 * @author chelsey
 *
 */
public class SignUpFormTestProgram {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		//Attributes to use for sign up form
		String serviceType = ("Weed Killing ");
		
		//Attributes to use for customers class
		String Fname = "Chelsey"; 
		String Lname = "Fay";
				
		//Create a customer object from the services class
		Services services = new Services();
		services.setsericeType(serviceType);
		
		//Create a customer object from the customers class
		Customers customers = new Customers();
		customers.setfirstName(Fname);
		customers.setLastName(Lname);
		
		String customersFN = customers.getfirstName();
		String customersLN = customers.getlastName();


		System.out.println("The customers name is: " + customersFN  + " " + customersLN);
		System.out.println("The type of service chosen is: " + services.getserviceType());
	}

}
