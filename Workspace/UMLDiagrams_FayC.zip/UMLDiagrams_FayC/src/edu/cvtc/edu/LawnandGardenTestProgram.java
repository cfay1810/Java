/**
 * 
 */
package edu.cvtc.edu;

/**
 * @author Chelsey Fay
 *
 */
public class LawnandGardenTestProgram {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		//Attributes to use for customer class
		String Fname = "Chelsey"; 
		String Lname = "Fay";
		String address = "123 Main St Menomonie,WI";
		String phoneNumber = "715-205-0090";
		
		//Create a customer object from the customers class
		Customers customers = new Customers();
		customers.setfirstName(Fname);
		customers.setLastName(Lname);
		customers.setAddress(address);
		customers.setphoneNumber(phoneNumber);
		
		String customersFN = customers.getfirstName();
		String customersLN = customers.getlastName();

		
		System.out.println("The customers name is: " + customersFN  + " " + customersLN);
		System.out.println("The customers address is: " + customers.getAddress());
		System.out.println("The customers phone number is: " + customers.getphoneNumber());
	}

}
