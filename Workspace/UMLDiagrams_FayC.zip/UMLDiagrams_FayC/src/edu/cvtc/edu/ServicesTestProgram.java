/**
 * 
 */
package edu.cvtc.edu;

/**
 * @author Chelsey Fay
 *
 */
public class ServicesTestProgram {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		//Attributes to use for services class
		String serviceType = ("Weed Killing ");
		String serviceDesc = ("Attempt to stop the weeds through herbicides and pulverizing seeds.");
		
		
		//Create a customer object from the services class
		Services services = new Services();
		services.setsericeType(serviceType);
		services.setserviceDesc(serviceDesc);

		System.out.println("The type of service chosen is: " + services.getserviceType());
		System.out.println("The service description is: " + services.getserviceDesc());
		
	}
}
