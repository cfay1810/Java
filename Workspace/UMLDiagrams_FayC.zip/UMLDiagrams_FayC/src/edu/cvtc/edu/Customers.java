/**
 * 
 */
package edu.cvtc.edu;

/**
 * @author Chelsey Fay
 *
 */
public class Customers {

	private String firstName; 
	private String lastName;
	private String address;
	private String phoneNumber;
	
	public String getfirstName() {
		return firstName;
	}
	
	public void setfirstName(String firstName){
		this.firstName = firstName;
	}
	
	public String getlastName() {
		return lastName;
	}
	
	public void setLastName(String lastName){
		this.lastName = lastName;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address){
		this.address = address;
	}
	
	public String getphoneNumber(){
		return phoneNumber;
	}
	
	public void setphoneNumber(String phoneNumber){
		this.phoneNumber = phoneNumber;
	}
}
	
