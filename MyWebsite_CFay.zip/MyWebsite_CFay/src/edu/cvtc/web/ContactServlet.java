package edu.cvtc.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Contact
 */
@WebServlet("/Contact")
public class ContactServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.append("<doctype! html><html><head><title>Contact Me</title></head><body>");
		out.append("<h1>Contact Me!</h1>");
		out.append("<nav>");
		out.append("<a href= ");
		out.append("/MyWesite/HomeServlet");
		out.append(">");
		out.append("Home ");
		out.append("</a> ");
		out.append("<a href= ");
		out.append("/MyWesite/AboutServlet");
		out.append(">");
		out.append(" About ");
		out.append("</a> ");
		out.append("<a href= ");
		out.append("/MyWesite/Contact");
		out.append(">");
		out.append("Contact");
		out.append("</a>");
		out.append("</nav>");
		out.append("<p>You can contact me at : 715/271-7940 ");
		out.append("or to contact me by email: ");
		out.append("<a href= ");
		out.append(" www.chelseyfay1810@gmail.com");
		out.append(">");
		out.append("chelseyfay1810@gmail.com");
		out.append("</a> ");
		out.append("</p>");
		out.append("<form>");
		out.append("<input type=text>");
		out.append("First Name <br>");
		out.append("<input type=text>");
		out.append("Last Name <br>");
		out.append("<input type=text>");
		out.append("Phone Number <br>");
		out.append("<input type=text>");
		out.append("E-Mail <br>");
		out.append("<button type= button");
		out.append(">");
		out.append("Submit");
		out.append("</button>");
		out.append("</form>");
		out.append("<p>&copy; Copyright 2016 Chelsey Fay</p>");
		out.append("</body></html>");
	//	response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
