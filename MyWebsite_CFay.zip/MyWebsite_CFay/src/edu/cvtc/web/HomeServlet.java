package edu.cvtc.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HomeServlet
 */
@WebServlet("/HomeServlet")
public class HomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// NOTES: 
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.append("<doctype! html><html><head><title>My Personal Website</title></head><body>");
		out.append("<h1>Welcome To My Website!</h1>");
		out.append("<nav>");
		out.append("<a href= ");
		out.append("/MyWesite/HomeServlet");
		out.append(">");
		out.append("Home ");
		out.append("</a> ");
		out.append("<a href= ");
		out.append("/MyWesite/AboutServlet");
		out.append(">");
		out.append(" About ");
		out.append("</a> ");
		out.append("<a href= ");
		out.append("/MyWesite/Contact");
		out.append(">");
		out.append("Contact");
		out.append("</a>");
		out.append("</nav>");
		out.append("<p>My name is Chelsey Fay. Welcome to my personal website. On this website you will get to know a little about"
				+ "me and learn what I like to do for fun!</p>");
		out.append("<p>&copy; Copyright 2016 Chelsey Fay</p>");
		out.append("</body></html>");
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
