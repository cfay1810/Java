package edu.cvtc.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AboutServlet
 */
@WebServlet("/AboutServlet")
public class AboutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.append("<doctype! html><html><head><title>About Me</title></head><body>");
		out.append("<h1>About Me!</h1>");
		out.append("<nav>");
		out.append("<a href= ");
		out.append("/MyWesite/HomeServlet");
		out.append(">");
		out.append("Home ");
		out.append("</a> ");
		out.append("<a href= ");
		out.append("/MyWesite/AboutServlet");
		out.append(">");
		out.append(" About ");
		out.append("</a> ");
		out.append("<a href= ");
		out.append("/MyWesite/Contact");
		out.append(">");
		out.append("Contact");
		out.append("</a>");
		out.append("</nav>");
		out.append("<p>Hobbies of mine include: ");
		out.append("<ul>");
		out.append("<li>");
		out.append("Video Gaming");
		out.append("</li>");
		out.append("<li>");
		out.append("Cooking");
		out.append("</li>");
		out.append("<li>");
		out.append("Crafting");
		out.append("</li>");
		out.append("<li>");
		out.append("Reading");
		out.append("</li>");
		out.append("</ul>");
		out.append("<h3>More about me:</h3>"
				+ "I grew up in North West Georgia mostly Cobb County area."
				+ " When I was 14 my mother decided she wanted to move back up north and somewhere safer so "
				+ " she moved to Wisconsin. Since being up here I've met my husband of three years, and we've created"
				+ " our two daughters. The oldest is almost two and the second one is due at the end of June. "
				+ " My husband is from River Falls, Wisconsin, but he lived in Oregon for a few years during his teenage years"
				+ " before I met him. Besides that part of my life, I enjoy being outdoors during the warmer months and during"
				+ " the winter I am a hermit. I am looking forward to graduating this fall, so I'm excited to be close to graduating "
				+ " finally. After graduation I plan on attending University of Illinois Online to obtain my Bachelors in Computer Science."
				+ " I just can't picture myself trying to attend class in person at a University, working full time, and helping taking care of"
				+ " our daughters. Well that's it for now I hope you learned a little about me. If you have any questions feel free to contact me"
				+ " on the contact page.");
		out.append("</p>");
		out.append("<p>&copy; Copyright 2016 Chelsey Fay</p>");
		out.append("</body></html>");
	//	response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
